console.log("Gdzie ja jestem???? Czy to konsola JS?");
console.log(2 + 2);
console.log("jakie 4???");
console.log("Witaj, jestem javascript. Miło mi Cię poznać");
var name = "JSON";
var surname = "Console";

var num1 = 731;
var num2 = 729;
var num3 = num1 * num2;
var num4 = num3 + num2;
var num5 = num4 / num1;
var num6 = 255;
//dodaj jeszcze trzy zmienne
console.log("Niech się przedstawie, niewiele pamiętam. Moje imię to chyba... " + name + ". Przynajmniej tak nazywałem się jakoś " + num3 + " lat temu");
console.log("A, zapomniałem o nazwisku. Moje nazwisko to oczywiście " + surname);
console.log("*wychodząc z pokoju nr " + num6  + " natknąłem się na dziwne coś na którym było napisane...[]*");
//tabela wartości num1 & num2;
console.log("TABELA WARTOŚCI NUMn (jest ich 5)");
console.log("num1 = " + num1);
console.log("num2 = " + num2);
//działania matematyczne na num1, num2, num3 i num4;
console.log("num3 = num1 x num2 = " + num3);
console.log("num4 = num3 + num2 = " + num4);
console.log("num5 = num4 / num1 = " + num5);


//praca domowa

//dopisanie komentarzy
//zmienna o wartosci
//zmienna o stringu
//console log co to
//jak zapisac zeby string sie wyswietlal
//albo wartosc liczbowa

//dodawanie

//odejmowanie

//mnożenie